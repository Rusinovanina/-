﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double r = double.Parse(textBox1.Text);
            double v = double.Parse(textBox3.Text);
            double voz = Double.Parse(textBox2.Text);
            double i = 0;

            if (radioButton1.Checked)
            {
                i = 66 + (13.7 * v) + (5 * r) - (6.8 * voz);
                double a = i * 1.2;
                label16.Text = a.ToString("##.##");
                double b = i * 1.375;
                label17.Text = b.ToString("##.##");
                double u = i * 1.55;
                label18.Text = u.ToString("##.##");
                double k = i * 1.725;
                label19.Text = k.ToString("##.##");
                double q = i * 1.9;
                label20.Text = q.ToString("##.##");
            }
            if (radioButton2.Checked)
            {
                i = 655 + (9.6 * v) + (1.8 * r) - (4.7 * voz);
                double a = i * 1.2;
                label16.Text = a.ToString("##.##");
                double b = i * 1.375;
                label17.Text = b.ToString("##.##");
                double u = i * 1.55;
                label18.Text = u.ToString("##.##");
                double k = i * 1.725;
                label19.Text = k.ToString("##.##");
                double q = i * 1.9;
                label20.Text = q.ToString("##.##");
            }
            label10.Text = i.ToString("##.##");
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
           panel1.Visible = true;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
          
        }

        private void label22_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        
        }
    }
}
